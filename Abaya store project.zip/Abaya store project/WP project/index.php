
<!DOCTYPE html>

    <head> 
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, intial-scale=1.0">
        <title>ORCHID ABAYA</title>
        <link rel="stylesheet" type="text/css" href="ProjectCss.css">
        
   </head>
    <body>

        <div class="header">
        <div class="container">
        <div class="navbar">
            <div class="logo">
               <a href="index.php"><img src="pimage/logo.png" width="90px"></a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.html">About us</a></li>
                    <li><a href="abaya.html">Abaya</a></li>
                    <li><a href="products.html">Tarhah</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><button class="btn " type="button"><a href="login.html"> Account</a></li>
                </ul>
             </nav>
             <img src="pimage/cart icon.png" width="30px" height="30px">
    </div>


    <!------ Ads what we have ------>
    <div class="row">
        <div class="col-2">
            <h1>Discount COLLECTION</h1>
            <p class="parg">  Our Discount collection<br></p>
                   <a href="disPage.html" class="btn">Explore Now &#8594;</a>
    </div>
        <div class="col-2">
            <img src="pimage/backg.png">
        </div>
    </div>
    <div class="row">
        <div class="col-2">
            <h1>Measurements</h1>
            <p>  Measure your size and get the perfect size for you<br></p>
                   <a href="mes.html" class="btn">Explore Now &#8594;</a>
    </div>
    <div class="col-2">
        <img src="pimage/backg3.png">
    </div>
    </div>
    <div class="row">
        <div class="col-2">
            <h1>Gift</h1>
            <p>  Gift someone you love through gift codes<br></p>
                   <a href="gift.html" class="btn">Explore Now &#8594;</a>
    </div>
    <div class="col-2">
        <img src="pimage/giftcard.jpg">
    </div>
    </div>
       
       
<!-------- featured categories -------->
   <div class="categories">
       <div class="small-container">
        <div class="row">
            <div class="col-3">
                <img src="pimage/backg2 (0_0).png" height="275" width="500">
                </div>
              <div class="col-3">
                 <img src="pimage/backg2 (0_1).png" height="275" width="500">
                 </div>
              <div class="col-3">
                 <img src="pimage/backg2 (0_2).png" height="275" width="500">
                 </div>
            </div>
       </div>
   </div>

<!------ Comment field ------>
<!-- Your HTML form goes here -->
<div class="comment form">
<h2 id="OrchidTitle">&#128156; Comments Our Beautiful Orchids &#128156;</h2>
    <fieldset class="fieldset">
        <legend>Comment</legend>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <input class="Tbox" type="text" name="Name" placeholder="Full Name" required>
            <p class="text">
                <textarea class="Tbox" name="Comment" id="comment" placeholder="Write An Orchid Comment As You..."
                    rows="3" cols="70" required></textarea>
                   
            </p>
            <div class="submit">
                <input class="btn" type="submit" value="SEND" />
            </div>
        </form>
    </fieldset>
   
</div>

<?php
// Inserting comments
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Name = test_input($_POST['Name']);
    $Comment = test_input($_POST['Comment']);

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'usercomment');
    if ($conn->connect_error) {
        echo "$conn->connect_error";
        die("Connection Failed: " . $conn->connect_error);
    } else {
        $stmt = $conn->prepare("INSERT INTO usersinfo (Name, Comment) VALUES (?, ?)");
        $stmt->bind_param("ss", $Name, $Comment);

        // Execute the statement
        $execval = $stmt->execute();

        // Check for success
        if (!$execval) {
            echo "Error: " . $stmt->error;
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    }
}


// Retrieve and display comments
// Database connection
$conn = new mysqli('localhost', 'root', '', 'usercomment');
if ($conn->connect_error) {
    echo "$conn->connect_error";
    die("Connection Failed: " . $conn->connect_error);
}

// Retrieve comments from the database
$result = $conn->query("SELECT Name, Comment FROM usersinfo");
if ($result->num_rows > 0) {
    echo '<div class="comment-container">';
    while ($row = $result->fetch_assoc()) {
        echo '<div class="comment">';
        echo '<p><strong>' . $row['Name'] . ':</strong> ' . $row['Comment'] . '</p>';
        echo '</div>';
    }
    echo '</div>';
} else {
    echo '<p>No comments yet.</p>';
}
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
// Close the database connection
$conn->close();
?>



<!------ footer ------>

<div class="footer">
    <div class="container">
        <div class="row">

            <div class="footer-col-1">
                <h3>Download our App</h3>
                <p>Available on Android and iOS</p>
                <div class="app-logo">
                    <img src="pimage/download our app icon.jpg">
                </div>
            </div>

            <div class="footer-col-2">
                <img src="pimage/logo.png" width="200px">
                <p>Copyright 2023 - Orchid Abaya </p>
            </div>

            <div class="footer-col-3">
                <h3>Useful Links</h3>
                <ul>
                    <li>Blog Post</li>
                    <li>Return Policy</li>
                    <li>Join our Club</li>
                </ul>
            </div>

            <div class="footer-col-4">
                <h3>Follow us</h3>
                <ul>
                    <li>Instagram</li>
                    <li>Twitter</li>
                    <li>Facebook</li>
                </ul>
            </div>

        </div>
        <hr>
        <p class="made">Made by Orchid Abaya</p>
    </div>
</div>

<script src="script.js"></script>

 </body>
</html>


