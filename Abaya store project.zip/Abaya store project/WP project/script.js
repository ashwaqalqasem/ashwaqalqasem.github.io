function calculateSize() {
    var height = document.getElementById("height").value;
    var weight = document.getElementById("weight").value;
    var sleeveLength = document.getElementById("sleeve-length").value;
  
    var size = "";
  
    if (height >= 155 && height <= 165 && weight >= 50 && weight <= 60 && sleeveLength <= 57) {
      size = "(S) (52)";
    } else if (height >= 165 && height <= 175 && weight >= 60 && weight <= 70 && sleeveLength <= 59) {
      size = "(M) (54)";
    } else if (height >= 165 && height <= 175 && weight >= 70 && weight <= 80 &&  sleeveLength <= 61) {
      size = "(L) (56)";
    } else if (height >= 150 && height <= 165 && weight >= 40 && weight < 50 && sleeveLength <= 55) {
      size = "(XS) (50)";
    } else if (height >= 175 && height <= 185 && weight >= 80 && weight <= 90 && sleeveLength <= 63) {
      size = "(XL) (58)";
    } else {
      size = "Not available";
    }
  
    document.getElementById("result").innerHTML = "Your Abaya size is: " + size;
  }
  // Set the specific date for the promotion (format: "YYYY-MM-DD")
const promotionDate = new Date("2023-12-7");

// Get the current date
const currentDate = new Date();

// Compare the current date with the promotion date
if (currentDate >= promotionDate) {
  // Code to display the promotional window
  window.alert("Welcome in women day! You have 20% descount!");

}

